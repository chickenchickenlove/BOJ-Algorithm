import requests

headers = {
    'X-Auth-Token': 'ff70653516db802805052f78eb7f8b03',
    'Content-Type': 'application/json',
}

data = '{"problem": 1}'

response = requests.post('https://kox947ka1a.execute-api.ap-northeast-2.amazonaws.com/prod/users/start', headers=headers, data=data)

print(response.status_code)
print(response.text)