import requests
import json



#https://kox947ka1a.execute-api.ap-northeast-2.amazonaws.com/prod/users
#auth key : 8b34c414-607d-40c4-bd3a-6117262411d9

base_url = 'https://kox947ka1a.execute-api.ap-northeast-2.amazonaws.com/prod/users'
lo_url = base_url + '/locations'
tr_url = base_url + '/trucks'
sim_url = base_url + '/simulate'
headers = {
            'Authorization': '12b20542-b770-4be2-993a-1d56423274ed',
            'Content-Type': 'application/json'
}

def get_locations() :
    locations = requests.get(lo_url, headers=headers)
    loca = [0 for _ in range(25)]
    a = json.loads(locations.content)
    for key, value in a.items():
        for i in value:
            idx, cnt = i['id'], i['located_bikes_count']
            loca[idx] = cnt
    return loca

def get_trucks() :
    trucks = requests.get(tr_url,headers = headers)
    trc = [[] for _ in range(5)]
    b = json.loads(trucks.content)
    for key, value in b.items():
        for i in value:
            idx, cnt, posi = i['id'], i['loaded_bikes_count'], i['location_id']
            trc[idx] = [cnt, posi]
    return trc

