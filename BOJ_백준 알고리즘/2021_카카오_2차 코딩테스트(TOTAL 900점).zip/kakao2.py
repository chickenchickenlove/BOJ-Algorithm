from function import sim_url, headers,base_url, get_trucks, get_locations
import requests
from collections import defaultdict
from collections import deque
import heapq
import json
import random
import sys

#truck 위치를 찾는다.


def move_truck() :
    map = [[0 for _ in range(60)] for _ in range(60)]


# 좌표를 idx로 바꿔주는 함수
def convert_posi_idx(posi) :
    row = posi // 60
    col = posi % 60
    return row,col
# idx를 좌표로 바꿔주는 함수
def conver_idx_posi(r,c) :
    return r * 60 + c
# 근처에 있는 정류장 찾을 때, 초기화 함수.
def init_near_station(loca,que,posi,v) :
    for idx, value in enumerate(loca) :
        if posi == idx :
            continue
        if value >= 2 :
            sr, sc = convert_posi_idx(idx)
            que.append((sr,sc,idx,0))
            v[sr][sc] = 0


    return que

# 근처에 있는 정류장 찾는 함수
def find_near_station(posi, loca) :
    answer = []
    v = [[0 for _ in range(60)] for _ in range(60)]
    er, ec = convert_posi_idx(posi)
    que = deque()

    init_near_station(loca,que,posi,v)
    tra_list = [[1,0],[0,1],[-1,0],[0,-1]]

    while que :
        now_r, now_c, origin_idx, now_time = que.popleft()
        next_time = now_time + 1
        if now_r == er and now_c == ec :
            if loca[origin_idx] >= 2 :
                answer.append(origin_idx)
            if len(answer) >= 4 :
                break

        for rr,cc in tra_list :
            next_r, next_c = now_r + rr, now_c + cc
            if -1 < next_r < 60 and -1 < next_c < 60 :
                if next_time <= 4 :
                    que.append((next_r, next_c, origin_idx, next_time))
                    v[next_r][next_c] = next_time

    return answer



# 가까이 있는 트럭을 찾는 함수
# posi는 현재 자전거를 실을 곳임
def find_near_truck(posi,trc,trc_remain_time) :
    que = deque()
    tra_list = [[1,0],[0,1],[-1,0],[0,-1]]
    answer = []

    # 정류장의 포지션 좌표 설정
    sr,sc = convert_posi_idx(posi)

    # 현재 트럭의 위치를 확인해서 좌표로 변경
    # 좌표로 변경 후 모두 que에 넣는다.
    #  trc[idx] = [cnt,posi]
    v = [[9876543210 for _ in range(60)] for _ in range(60)]
    for idx,value in enumerate(trc) :
        tr,tc = convert_posi_idx(value[1])
        que.append((tr,tc,posi,0,idx))
        v[tr][tc] = 0

    # time limt은 6초다
    while que :
        tr, tc, origin_posi, now_time, truck_name = que.popleft()
        next_time = now_time + 1


        if tr == sr and tc == sc :
            answer.append((truck_name, now_time))


        for rr, cc in tra_list :
            next_r, next_c = tr + rr, tc + cc
            if -1 < next_r < 60 and -1 < next_c <  60 :
                if v[next_r][next_c] > next_time :
                    que.append((next_r, next_c, origin_posi, next_time, truck_name))
                    v[next_r][next_c] = next_time
    return answer


def move_truck_time(from_,to_) :

    que = deque()
    tra_list = [[1,0],[0,1],[-1,0],[0,-1]]
    sr, sc = convert_posi_idx(from_)
    er, ec = convert_posi_idx(to_)
    que.append((sr,sc,0 ))

    while que :
        r, c , now_time = que.popleft()
        next_time = now_time + 1
        if r == er and c == ec  :
            return now_time
        for rr, cc in tra_list :
            next_r = r + rr
            next_c = c + cc
            if -1< next_r < 60 and -1 < next_c < 60 :
                if next_time <=6 :
                    que.append((next_r, next_c, next_time))

    return -1

# 트럭의 이동경로를 표시해주는 함수
# 0 : 대기
# 1 : 위
# 2 : 오른쪽
# 3 : 아래
# 4 : 왼쪽
# 5 : 상차
# 6 : 하차
def find_path_name(from_, to_) :
    que = deque()

    tra_list = [[1,0,2],[0,1,1],[-1,0,4],[0,-1,3]]
    v = [[9876543210 for _ in range(60)] for _ in range(60)]

    sr,sc = convert_posi_idx(from_)
    er,ec = convert_posi_idx(to_)

    que.append((sr,sc,0,''))
    v[sr][sc] = 0

    while que :
        r, c , now_time ,path = que.popleft()
        next_time = now_time + 1

        if r == er and c == ec :
            return path

        for rr,cc,direction in tra_list :
            next_r, next_c = r + rr , c + cc
            if -1 < next_r < 60 and -1 < next_c < 60 :
                if v[next_r][next_c] > next_time :
                    que.append((next_r, next_c, next_time, path + str(direction) + ','))
                    v[next_r][next_c] = next_time


def make_hq(hq, trc_to_load, from_, to_, trc_remain_time) :
    for truck_name, truck_time in trc_to_load :
        move_time = move_truck_time(from_, to_)
        if move_time == -1 :
            continue

        if (move_time + truck_time) * 6  + 12 <= trc_remain_time[truck_name] :
            heapq.heappush(hq, ((move_time + truck_time) * 6  + 12, truck_name, from_, to_))

    return hq

def add_trc_command(truck_name, command, trc_command) :
    for c in command :
        trc_command[truck_name].append(int(c))



# 트럭의 이동경로를 계산하는 함수
def cal_distance(from_,to_,trc, trc_remain_time, trc_command) :
    hq = []
    # 가까이 있는 트럭을 찾아서 From까지의 거리를 저장한다.
    trc_to_load = find_near_truck(from_,trc, trc_remain_time)
    hq = make_hq(hq, trc_to_load, from_, to_, trc_remain_time)
    # From부터 to까지의 거리를 계산한다.


    if hq :
        while loca[to_] <= 2 :
            if len(hq) == 0:
                break
            total_time, truck_name, from_station, to_stations = heapq.heappop(hq)
            if truck_name == 9 :
                continue

            truck_path1 = find_path_name(trc[truck_name][1] ,from_)
            truck_path2 = find_path_name(from_, to_)

            if loca[from_] <= 1  :
                continue
            truck_path = truck_path1 + '5,' + truck_path2 + '6,'
            truck_path = list(truck_path.split(','))
            truck_path.pop()

        # trc에게 남은 시간 및 현재 위치 업데이트 해두기
            trc_remain_time[truck_name] -= total_time
            trc[truck_name][1] = to_
            loca[from_] -= 1
            loca[to_] += 1

            add_trc_command(truck_name, truck_path, trc_command)



def cal_distance2(to_,trc, trc_remain_time, trc_command) :
    hq = []
    # 가까이 있는 트럭을 찾아서 From까지의 거리를 저장한다.
    truck_time = move_truck_time(trc[9][1], to_)

    truck_path1 = find_path_name(trc[9][1], to_)

    total_truck_time = truck_time * 6 + (2 + 2 ) * 6 + (2*6)
    truck_path = truck_path1
    while loca[to_] > 2 :
        truck_path += '5,'
        loca[to_] -=1




    truck_path = list(truck_path.split(','))
    truck_path.pop()

    trc_remain_time[9] -= total_truck_time
    loca[to_] -= 2
    add_trc_command(9, truck_path, trc_command)
    # From부터 to까지의 거리를 계산한다.


def make_st_list(max_v, max_idx, loca, st_list) :

    for idx, value in enumerate(loca):
        if max_v < value:
            max_v = value
            max_idx = idx
        if value < 1:
            st_list.append((value, idx))
    st_list = sorted(st_list)
    return max_idx

def find_aaa() :
    max_v = 0
    max_idx = 0
    st_list = []
    make_st_list(max_v, max_idx,loca, st_list)

    for to_,value in st_list :
        a = find_near_station(to_, loca)
        for from_ in a :
            if loca[from_] >= 2 :
                cal_distance(from_, to_, trc, trc_remain_time, trc_command)

    if max_v > 2 :
        cal_distance2(max_idx, trc, trc_remain_time, trc_command)

def trc_thorw() :
    for i in range(10):

        if trc[i][0] > 0:
            tr, tc = convert_posi_idx(trc[i][1])
            tratra = [1, 2, 3, 4]
            while trc[i][0] > 0 and trc_remain_time[i] >= 18:
                k = random.sample(tratra, 1)[0]
                if k == 1:
                    tc = tc + 1
                elif k == 2:
                    tr = tr + 1
                elif k == 3:
                    tc = tc - 1
                elif k == 4:
                    tr = tr - 1

                if -1 < tr < 60 and -1 < tc < 60:

                    idx = conver_idx_posi(tr, tc)
                    if loca[idx] > 2:

                        truck_path = f'{k},'
                        truck_path = list(truck_path.split(','))
                        truck_path.pop()
                        trc_remain_time[i] = trc_remain_time[i] - 6
                        add_trc_command(i, truck_path, trc_command)
                        trc[i][1] = idx


                    else:
                        if trc_remain_time[i] < 18:

                            break


                        truck_path = f'{k},' + '6,' + '6,'

                        truck_path = list(truck_path.split(','))
                        truck_path.pop()

                        trc_remain_time[i] = trc_remain_time[i] - 18
                        add_trc_command(i, truck_path, trc_command)
                        trc[i][1] = idx





#a = str(sys.stdin.readline().rstrip())
a = 'a'
if a == 'Y' :
    now_status = 'ready'
    while now_status == 'ready':
        d = '{"commands" : [ {"truck_id" : 0, "command" : [0]} ]}'
        a = requests.put(sim_url,headers = headers, data = d)
        print(a.content)
        b = json.loads(a.content)
        now_status = b['status']
        now_time = b['time']
        if now_time >= 720 :
            break

    score = requests.get(base_url + '/score', headers=headers)
    print(score.text)
    exit()


def sol1() :
    st_list = []
    max_v = 0
    max_idx = 0
    max_idx = make_st_list(max_v, max_idx, loca, st_list)

    for i in range(8, 10):
        if i > len(st_list) - 1:
            continue

        my_path = find_path_name(trc[i][1], max_idx)
        my_path = list(my_path.split(','))
        my_path.pop()
        tr, tc = convert_posi_idx(trc[i][1])

        # 10개보다 많은 자전거를 가지고 있다면.
        # 주변에 뿌리도록 한다.
        if trc[i][0] >= 10:
            truck_path = ''
            tr, tc = convert_posi_idx(trc[i][1])
            tratra = [1, 2, 3, 4]
            while trc[i][0] > 0 and trc_remain_time[i] >= 18:
                k = random.sample(tratra, 1)[0]
                if k == 1:
                    tc = tc + 1
                elif k == 2:
                    tr = tr + 1
                elif k == 3:
                    tc = tc - 1
                elif k == 4:
                    tr = tr - 1

                if -1 < tr < 60 and -1 < tc < 60:
                    idx = conver_idx_posi(tr, tc)
                    truck_path += f'{k},'
                    trc_remain_time[i] -= 6
                    trc[i][1] = idx
                    if trc_remain_time[i] == 0:
                        break
                    else:
                        #print(loca[idx])
                        if loca[idx] <= 5:
                            truck_path += '6,6,'
                            trc_remain_time[i] -= 12

            truck_path = list(truck_path.split(','))
            truck_path.pop()
            add_trc_command(i, truck_path, trc_command)

        elif len(my_path) == 0:
            truck_path = ''
            while loca[max_idx] > 2:
                truck_path += '5,'
                trc_remain_time[i] -= 6
                loca[max_idx] -= 1

                if trc_remain_time[i] == 0:
                    break
            truck_path = list(truck_path.split(','))
            truck_path.pop()
            add_trc_command(i, truck_path, trc_command)

        else:
            truck_path = ''
            for c in my_path:
                k = int(c)
                # while trc_remain_time[i] > 6:
                if k == 1:
                    tc = tc + 1
                elif k == 2:
                    tr = tr + 1
                elif k == 3:
                    tc = tc - 1
                elif k == 4:
                    tr = tr - 1

                if -1 < tr < 60 and -1 < tc < 60:

                    idx = conver_idx_posi(tr, tc)
                    truck_path += f'{k},'
                    trc_remain_time[i] -= 6
                    trc[i][1] = idx
                    if trc_remain_time[i] == 0:
                        break

                    # 3대면 싣는다.
                    if loca[idx] > 2 and trc[i][0] < 2:
                        truck_path += '5,'
                        trc_remain_time[i] -= 6


                    # 없으면 내린다.
                    elif loca[idx] < 1 and trc[i][0] > 1:
                        truck_path += '6,'
                        trc_remain_time[i] -= 6

                    if trc_remain_time[i] == 0:
                        break
            truck_path = list(truck_path.split(','))
            truck_path.pop()
            add_trc_command(i, truck_path, trc_command)


    for i in range(8):
        if i > len(st_list) - 1  :
            continue

        my_path = find_path_name(trc[i][1], st_list[i][1] )
        my_path = list(my_path.split(','))
        my_path.pop()
        tr, tc = convert_posi_idx(trc[i][1])

        truck_path = ''
        for c in my_path :
            k = int(c)
        #while trc_remain_time[i] > 6:
            if k == 1:
                tc = tc + 1
            elif k == 2:
                tr = tr + 1
            elif k == 3:
                tc = tc - 1
            elif k == 4:
                tr = tr - 1

            if -1 < tr < 60 and -1 < tc < 60:

                idx = conver_idx_posi(tr, tc)
                truck_path += f'{k},'
                trc_remain_time[i] -=6
                trc[i][1] = idx
                if trc_remain_time[i] == 0 :
                    break

                    #3대면 싣는다.
                if loca[idx] > 2 and trc[i][0] < 2:
                    truck_path += '5,'
                    trc_remain_time[i] -= 6
                    trc[i][0] +=1



                    #없으면 내린다.
                elif loca[idx] < 1 and trc[i][0] > 1 :
                    truck_path += '6,'
                    trc_remain_time[i] -= 6
                    trc[i][0] -=1


            if trc_remain_time[i] == 0 :
                    break

        truck_path = list(truck_path.split(','))
        truck_path.pop()
        add_trc_command(i, truck_path, trc_command)




#부족한 곳을 찾아가는 방식으로 접근해야할 듯.
#부족한 곳을 가면서 있으면 태우고 없으면 내리고.




now_status = 'ready'
while now_status == 'ready' :
    trc_command = defaultdict(list)
    trc_remain_time = [60 for _ in range(10)]
    loca = get_locations()
    trc = get_trucks()
    print(loca)
    print(trc)

# 현재 트럭에 자전거가 있으면, 부족한 곳으로 이동하면서 한대씩 싣고 내린다.


    sol1()
 #   trc_thorw()
#    find_aaa()

    obj1 = defaultdict(dict)
    for key,value in trc_command.items() :
        obj1[key]['truck_id'] = key
        obj1[key]['command'] = value


    obj2 = {}
    obj2['commands'] = []
    for value in obj1.values() :
        obj2['commands'].append(value)


    obj3 = json.dumps(obj2)
    a = requests.put(sim_url,headers = headers, data = obj3 )

    print(a.content)
    b = json.loads(a.content)
    now_status = b['status']


score = requests.get(base_url + '/score', headers = headers)
print(score.content)